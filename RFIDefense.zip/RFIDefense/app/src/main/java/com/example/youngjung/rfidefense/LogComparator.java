package com.example.youngjung.rfidefense;

import java.util.Comparator;

public class LogComparator implements Comparator<LogEntry>{
    @Override
    public int compare(LogEntry le1, LogEntry le2) {
        return le2.compareTo(le1);
    }
}
