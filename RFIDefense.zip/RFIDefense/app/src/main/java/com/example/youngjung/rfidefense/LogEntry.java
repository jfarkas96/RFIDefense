package com.example.youngjung.rfidefense;

import java.text.SimpleDateFormat;
import java.util.Date;

public class LogEntry implements Comparable<LogEntry> {

    public String id;
    public String access;
    public Date datetime;
    SimpleDateFormat formatter = new SimpleDateFormat("MMM dd, yyyy hh:mm:ss a");


    public LogEntry() {
        // Default constructor required for calls to DataSnapshot.getValue(LogEntry.class)
    }

    public LogEntry(String id, String access, String datetime) {
        this.id = id;
        this.access = access;
        try {
            this.datetime = formatter.parse(datetime);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getID() {
        return this.id;
    }

    public String getAccess() {
        return this.access;
    }

    public Date getDateTime() {
        return this.datetime;
    }

    @Override
    public int compareTo(LogEntry le) {
        return this.getDateTime().compareTo(le.getDateTime());
    }

}
