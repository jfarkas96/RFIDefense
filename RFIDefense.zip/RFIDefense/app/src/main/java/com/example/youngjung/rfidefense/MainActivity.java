package com.example.youngjung.rfidefense;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.os.Handler;


import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {
private ArrayList<LogEntry> logEntryList = new ArrayList<>();
private ArrayList<String> logList = new ArrayList<>();
private final Handler handler = new Handler();
private final SimpleDateFormat formatter = new SimpleDateFormat("MMM dd, yyyy hh:mm:ss a");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView lv = (ListView) findViewById(R.id.listview);
        final ArrayAdapter<String> itemsAdapter =
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, logList);
        lv.setAdapter(itemsAdapter);
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("log");
        ref.addListenerForSingleValueEvent(
                new ValueEventListener() {

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        try {
                            collectLog((Map<String, Object>) dataSnapshot.getValue());
                            logEntryList.sort(new LogComparator());
                            for (int i=0; i<logEntryList.size();i++) {
                                logList.add("\n" +"RFID: " + logEntryList.get(i).getID() + "\n" + "Access: " + logEntryList.get(i).getAccess() + "\n" + formatter.format(logEntryList.get(i).getDateTime()) + "\n");
                            }
                        } catch (Exception e) {
                            if (logList.size()==0){
                                logList.add("   ");
                            }
                        }

                        itemsAdapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
        doTheAutoRefresh(ref, itemsAdapter);
    }

    private void collectLog(Map<String,Object> log) {
        for (Map.Entry<String, Object> entry : log.entrySet()) {
            Map singleUser = (Map) entry.getValue();
            Long id = (Long) singleUser.get("id");
            logEntryList.add(new LogEntry(Long.toString(id), (String) singleUser.get("access"), (String) singleUser.get("datetime")));
        }
    }

    private void doTheAutoRefresh(final DatabaseReference ref, final ArrayAdapter<String> itemsAdapter) {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ref.addListenerForSingleValueEvent(
                        new ValueEventListener() {

                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                logEntryList.clear();
                                logList.clear();
                                try {
                                    collectLog((Map<String, Object>) dataSnapshot.getValue());
                                    logEntryList.sort(new LogComparator());
                                    for (int i=0; i<logEntryList.size();i++) {
                                        logList.add("\n" + "RFID: " + logEntryList.get(i).getID() + "\n" + "Access: " + logEntryList.get(i).getAccess() + "\n" + formatter.format(logEntryList.get(i).getDateTime()) + "\n");
                                    }
                                } catch (Exception e) {
                                    if (logEntryList.size()==0){
                                        logList.add("   ");
                                    }
                                }
                                itemsAdapter.notifyDataSetChanged();
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {

                            }
                        });
                doTheAutoRefresh(ref,itemsAdapter);
            }
        }, 2000);
    }

}
